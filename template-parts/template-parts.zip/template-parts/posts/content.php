<?php
/**
 * TEMPLATE TO DISPLAY CONTENT OF THEMES
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package finaltheme
 * @version 1.0
 */

?>

<article id="post-<?php the_ID(); ?>"  <?php post_class(); ?> > 

	<div class="entry-header">

		<a href="<?php the_permalink(); ?>"> 
			<?php the_title(); ?>
		</a>
	
	</div><!-- entryHeader-->


	<div class="entry-content">

		<?php the_content(); ?>

<?php  if(is_single()) {?>
<div class="wrap_posts_previous_next">
<ul class="list-unstyled list-inline">
<li class="pull-left"><?php previous_post_link(); ?></li>
<li class="pull-right"><?php next_post_link();  ?></li>
</ul>
</div>

<?php } ?>


	</div><!-- entryHeader-->


	<div class="entry-footer">


	</div><!-- entryHeader-->



</article>