<?php 

echo "Bye World"; 