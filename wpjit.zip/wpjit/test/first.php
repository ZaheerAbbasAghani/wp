<?php 

echo "<h3> Q: 1-Write a function that list name of all the files changed within one hour in given directory </h3>";

//Put here the directory you want to search for. Put / if you want to search your entire domain
date_default_timezone_set("Asia/Karachi");
$d = dirname(__FILE__);
$dir=$d.'/inc';

//Put the date you want to compare with in the format of:  YYYY-mm-dd hh:mm:ss

$comparedatestr="2017-04-23 00:00:00";
$comparedate=strtotime($comparedatestr);

//I run the function here to start the search. 
my_file_directory($dir,$comparedate);

//This is the function which is doing the search...
function my_file_directory($address,$comparedate){ 

@$dir = opendir($address); 

  if(!$dir){ return 0; } 
        while($entry = readdir($dir)){ 
                if(is_dir("$address/$entry") && ($entry != ".." && $entry != ".")){                             
                        my_file_directory("$address/$entry",$comparedate);
                } 
                 else   {

                  if($entry != ".." && $entry != ".") {
                  
                    $fulldir=$address.'/'.$entry;
                    $last_modified = filemtime($fulldir);
                    $last_modified_str= date("Y-m-d h:i:s", $last_modified);

                       if($comparedate < $last_modified)  {
                          echo $fulldir.'=>'.$last_modified_str;
                          echo "<BR>";
                       }

                 }

            }

      } 

}

/* */