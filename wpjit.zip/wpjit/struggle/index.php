<?php 
/*
Plugin Name:Struggle
Plugin URI: http://www.google.com
Description: Plug and Play Plugins
Author: Zaheer Abbas Aghani
Author URI: http://www.google.com
Version:1.0
*/

define('STR_PATH',WP_PLUGIN_URL.'/'. plugin_basename(dirname(__FILE__)).'/' );
define('STR_NAME','struggle_name');
define('STR_VERSION','1.0');
define('STR_SLUG','str_plugin');


function my_first_function(){
include('/template/post_types.php');
include('/inc/shortcode.php');
}


add_action('init','my_first_function');