<?php 

// CUSTOM POST TYPE WORDPRESS


$args = array(
'label' => __('Business Manager'),
'singular_label' => __('Business'),
'public' => true,
'show_ui' => true,
'capability_type' => 'post',
'hierarchical' => true,
'has_archive' => true,
'supports' => array('title', 'editor', 'thumbnail'),
'rewrite' => array('slug' => 'businesses', 'with_front' => false), );


// Register Custom Taxonomies
register_taxonomy("business-type", array("business"), array("hierarchical" => true, "label" => "Business Types", "singular_label" => "Business Type", "rewrite" => true, "slug" => 'business-type'));

register_post_type('business' , $args);   

?>