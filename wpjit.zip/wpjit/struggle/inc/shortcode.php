<?php
function myplugincss() {
wp_enqueue_style( 'styleSTR', STR_PATH.'template/styleStr.css');

}

add_action('wp_enqueue_scripts','myplugincss');

function display_shortcode() {

//wp_list_categories();

 $args = array('orderby' => 'name', 'hierarchical' => 0, 'parent' => 0, 'style' => 'none', 'taxonomy' => 'category', 'hide_empty' => 0, 'depth' => 1, 'title_li' => '');
    
    foreach(get_categories($args) as $category)
    {
    echo ' <li><a href="' . get_category_link($category->cat_ID) . '" title="' . $category->name . '">' . $category->name . '</a> </li>';
    }


}

add_shortcode('dp','display_shortcode');