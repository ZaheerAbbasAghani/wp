<?php

function final_display_of_contact_form() {

require get_template_directory().'/inc/contact_form.php';

}

add_shortcode( 'contact_form', 'final_display_of_contact_form' );