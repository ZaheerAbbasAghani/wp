<?php 
add_action( 'wp_ajax_nopriv_shaheen_save_user_contact_form', 'shaheen_save_contact' );
add_action( 'wp_ajax_shaheen_save_user_contact_form', 'shaheen_save_contact' );

function shaheen_save_contact(){
	$title = wp_strip_all_tags($_POST["name"]);
	$email = wp_strip_all_tags($_POST["email"]);
	$message = wp_strip_all_tags($_POST["message"]);

	echo $title.' '.$email .''.$message;


	/*$args = array(
    'post_title' => $title,
    'post_content' => $message,
    'post_status' => 'publish',
    'post_author' => 1,
    'post_type' => 'shaheen-contact',
    'meta_input' => array(
        '_contact_email_value_key' => $email,
        ),
        
    );
    // Mail trap if you are on local Machine
	$postID = wp_insert_post($args);
    if ($postID !== 0) {
        $to = get_bloginfo('admin_email');
        $subject = 'Shaheen Contact Form - '.$title;
        $headers[] = 'From: '.get_bloginfo('name').' <'.$to.'>'; // 'From: Alex <me@alecaddd.com>'
        $headers[] = 'Reply-To: '.$title.' <'.$email.'>';
        $headers[] = 'Content-Type: text/html: charset=UTF-8';
        wp_mail($to, $subject, $message, $headers);
    }
    echo $postID;*/
    die();
}