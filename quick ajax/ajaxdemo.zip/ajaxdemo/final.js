jQuery(document).ready(function(){

	jQuery('.custom-logo-link').addClass('navbar-brand');
	jQuery('.custom-logo').addClass('img-responsive');
 

 /* contact form submission */
	jQuery('#shaheenContactForm').on('submit', function(e){
       
		e.preventDefault();
         jQuery('.has-error').removeClass('has-error');
         jQuery('.js-show-feed').removeClass('js-show-feed');

		var form = jQuery(this),
        name = form.find('#name').val(),
        email = form.find('#email').val(),
        message = form.find('#message').val(),
        ajaxurl = form.data('url');
     
		if( name === ''){
        jQuery('#name').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        if( email === ''){
        jQuery('#email').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        if( message === ''){
        jQuery('#message').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        form.find('input , button , textarea').attr('disabled','disabled');
        jQuery('.js-form-submission').addClass('js-show-feed');
        
       

		jQuery.ajax({
			
		    url: ajaxurl,
			type: 'post',
			data : {
				name : name,
				email : email,
				message : message,
				action: "shaheen_save_user_contact_form",
				
			},
			error : function( response ){
		
          alert('Something went wrong');
            
			},
			success : function( response ){
				alert('SUCCESS');
                } //endif
               
			
		}); 

  	//end ajax

        
});



});


