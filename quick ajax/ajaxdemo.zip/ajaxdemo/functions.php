<?php
/**
 * TEMPLATE TO ADD FUNCTIONALITY IN FINAL THEME
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package finaltheme
 * @version 1.0
 */


require get_template_directory().'/inc/enqueue.php';
require get_template_directory().'/inc/function-admin.php';
require get_template_directory().'/inc/shortcodes.php';
require get_template_directory().'/inc/vendor/final-bootstrap-walker.php';

add_action( 'after_setup_theme', 'wc_zaheer' );

function wc_zaheer() {
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}