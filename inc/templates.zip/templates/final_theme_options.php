<div class="wrap">


<form method="post" action="options.php">

<?php

settings_fields('final-theme-options'); 
do_settings_sections('final_theme_options');

?>
 
<?php submit_button(); ?>

</form>

</div><!--wrap-->
