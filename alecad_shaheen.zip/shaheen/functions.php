<?php 

require get_template_directory() .'/inc/cleanUp.php';
require get_template_directory() .'/inc/functions-admin.php';
require get_template_directory() .'/inc/enqueue.php';
require get_template_directory() .'/inc/theme-support.php';
require get_template_directory() .'/inc/templates/contact-post-type.php';
require get_template_directory() .'/inc/walker.php';
require get_template_directory() .'/inc/ajax.php';
require get_template_directory() .'/inc/shortcodes.php';
require get_template_directory() .'/inc/widgets.php';
require get_template_directory() .'/inc/vendor/Mobile_Detect.php';