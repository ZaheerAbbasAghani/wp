/* Variable Declaration */
var last_scroll = 0;

/* Ajax Functions */

jQuery(document).ready(function($) {
    revealPosts();
	jQuery( '.shaheen-sidebar' ).addClass( 'sidebar-closed' );
    $(document).on('click','.shaheen-load-more:not(.loading)',function(){
        
        
        var that = $(this);
        var page =  
        that.data('page');
        var newPage = page+1;
        var ajaxUrl =  that.data('url');
        var prev = that.data('prev');
        
        if(typeof prev === 'undefined'){
            prev = 0;
        }
        
        that.addClass("loading").find('.text').slideUp(320);
        that.find('.glyphicon-refresh').addClass('spin');
    
    $.ajax({
       
        url : my_ajax_object.ajax_url,
        type: 'post',
        data : {
            page: page,
            prev: prev,
            action: 'shaheen_load_more',
        },
        
        error : function (response) {
            console.log(response);
        },
        
        success : function (response) {
            
            if(response==0){
               $('.sunset-posts-container').append("<div class='text-center'> <h3> No More Posts To Load. </h3></div>");
               that.slideUp(320);
               }
            else {
                
            setTimeout(function() {

            if(prev==1){

            $('.sunset-posts-container').prepend(response);
            newPage = page-1;
            }
            else {
            $('.sunset-posts-container').append(response);
            }
                
            if(newPage == 1 ){
                 that.slideUp(320);
            }else{
                   that.data('page',newPage);
                 that.removeClass("loading").find('.text').slideDown(320);
            that.find('.glyphicon-refresh').removeClass('spin');
            }
                
                revealPosts();
            }, 200);

            }
            
         
        
        
            
            
        },
    });
        
    });
    
    
    /* SCROLL FUNCTIONS */
    
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        //console.log(scroll);
       
        if(Math.abs(scroll - last_scroll)> $(window).height()*0.1) {
            last_scroll = scroll;
            
            $('.page-limit').each(function(index) {
                
                if(isVisible($(this))) {
                   // console.log('visible');
                    history.replaceState(null, null , $(this).attr("data-page"));
                    return false;
                }
                
            });
           
        }//endif
        
    });
    
    /* Helper Class */
    
    function revealPosts() {
        
        var posts = $('article:not(.reveal)');
        var i=0;
    setInterval(function() {
        if( i>=posts.length ) return false;
        var el = posts[i];
        $(el).addClass('reveal');
        i++;
    },200);
        
        
         $('[data-toggle="tooltip"]').tooltip();
         $('[data-toggle="popover"]').popover(); 
    
                }
            
            
        function isVisible( element ) {
            var scroll_pos = $(window).scrollTop();
            var window_height = $(window).height();
            var el_top = $(element).offset().top;
            var el_height =  $(element).height();
            var el_bottom = el_top + el_height;
            return ( (el_bottom - el_height*0.25 > scroll_pos) && (el_top  < ( scroll_pos + 0.5* window_height )) );
            
        }
    
    /* sidebar functions */
	jQuery(document).on('click', '.js-closeSidebar', function() {
    	jQuery( '.shaheen-sidebar' ).addClass( 'sidebar-closed' );
        jQuery('.sidebar-overlay').fadeOut();
       
    });       
  
    jQuery(document).on('click', '.js-openSidebar', function() {
    	jQuery( '.shaheen-sidebar' ).removeClass( 'sidebar-closed' );
        jQuery('body').addClass('no-scroll');
         jQuery('.sidebar-overlay').fadeToggle(320);
     
        
    });      
    
    /*jQuery(document).on('click', '.js-toggleSidebar', function() {
       
    	jQuery( '.shaheen-sidebar' ).toggleClass( 'sidebar-closed' );
       // jQuery('.sidebar-overlay').toggle(320);
    });*/  
    
    /* CONTACT FORM  */
    
    /* contact form submission */
	$('#shaheenContactForm').on('submit', function(e){
       
		e.preventDefault();
         $('.has-error').removeClass('has-error');
         $('.js-show-feed').removeClass('js-show-feed');

		var form = $(this),
        name = form.find('#name').val(),
        email = form.find('#email').val(),
        message = form.find('#message').val(),
        ajaxurl = form.data('url');
     
		if( name === ''){
        $('#name').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        if( email === ''){
        $('#email').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        if( message === ''){
        $('#message').parent('.form-group').addClass('has-error');
			//console.log('Required inputs are empty');
			return;
		}
        
        form.find('input , button , textarea').attr('disabled','disabled');
        $('.js-form-submission').addClass('js-show-feed');
        
       

		$.ajax({
			
		    url: ajaxurl,
			type: 'post',
			data : {
				name : name,
				email : email,
				message : message,
				action: "shaheen_save_user_contact_form",
				
			},
			error : function( response ){
		
            $('.js-form-submission').removeClass('js-show-feed');
            $('.js-form-error').addClass('js-show-feed');
            form.find('input , button , textarea').removeAttr('disabled');
                
            
			},
			success : function( response ){
				if(response == 0){
                //console.log('Unable to save your message');
            setTimeout(function(){
                $('.js-form-submission').removeClass('js-show-feed');
                $('.js-form-error').addClass('js-show-feed');
                form.find('input , button , textarea').removeAttr('disabled');
            },100);	
                } //endif
                else{ 
            setTimeout(function(){
                $('.js-form-submission').removeClass('js-show-feed');
                $('.js-form-success').addClass('js-show-feed');
                form.find('input , button , textarea').removeAttr('disabled').val('');
            },100);	
                }
			}
			
		}); 
	});

});

