jQuery(document).ready(function($){
var updateCss = function() { jQuery('#shaheen_css').val(editor.getSession().getValue());
 
}
   jQuery('#shaheen-save-custom-css').submit(updateCss);
    
});

var editor = ace.edit('csseditor');
editor.setTheme('ace/theme/monokai');
editor.getSession().setMode("ace/mode/css");