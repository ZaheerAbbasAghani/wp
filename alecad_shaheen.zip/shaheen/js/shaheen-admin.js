jQuery(document).ready(function($){

var mediaUploader;

jQuery('#uploadProfile').on('click'	,function(e){
	e.preventDefault();
	if(mediaUploader){
		
		mediaUploader.open();
		return;
	}
	
	mediaUploader = wp.media.frames.file_frame = wp.media({
		
		title: "Choose a Profile Picture",
		button:{
			text:"Choose Picture",
			
		},
		multiple:false,
		
	});
	
	mediaUploader.on('select',function(){
		attachment = mediaUploader.state().get('selection').first().toJSON();
		jQuery('#profile-picture').val(attachment.url);
		jQuery('#wrapUp').css('background-image','url('+attachment.url+')');	
	}); 
		
		
	mediaUploader.open();
	
});

jQuery('#removeProfile').on('click'	,function(e){
	e.preventDefault();
	var answer = confirm('Are You Sure ?');
	if(answer==true){
	jQuery('#profile-picture').val('');	
	jQuery('.shaheen-sidebar-form').submit();
	}
	return;
});
























});