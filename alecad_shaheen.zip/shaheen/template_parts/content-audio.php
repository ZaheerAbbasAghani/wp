<?php

/*
@package shaheen
==================================
Audio post fromat
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('sunset-format-audio'); ?>> 
    
    <header class="entry-class text-center">
    
         <?php the_title('<h1 class="entry-title">','</h1>'); ?>
        <div class="entry-meta">
        <?php echo shaheen_posted_meta(); ?>
        
        </div><!--entryMeta-->
        
    </header>
    
    <div class="entry-content">
    
    <?php $content = do_shortcode(apply_filters('the_content',$post->post_content)); 
          $embed= get_media_embedded_in_content($content,array('audio','iframe'));
              
        echo str_replace ('?visual=true','?visual=false',$embed[0]);
        
    ?>
        
        
    </div><!--entry-content-->
    
   
    
    <div class="entry-footer"> 
         <?php echo shaheen_posted_footer(); ?>
    </div><!--entry-footer-->
    
    
</article>