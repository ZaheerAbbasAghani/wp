<?php

/*
@package shaheen
==================================
Page  Template
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
    
    <header class="entry-class text-center">
    
         <?php the_title('<h1 class="entry-title">','</h1>'); ?>
        <div class="entry-meta">
        <?php echo shaheen_posted_meta(); ?>
        
        </div><!--entryMeta-->
        
    </header>
    
    <div class="entry-content">
      
   <?php the_content(); ?>
    
    </div><!--entry-content-->
    
 
    
    
    
    
    
</article>