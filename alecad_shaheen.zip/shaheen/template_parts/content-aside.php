<?php

/*
@package shaheen
==================================
Aside post fromat
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('shaheen-format-aside'); ?>> 
    
    <div class="aside-container">
    <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-2 text-center">
            
<?php   if(has_post_thumbnail()): ?>
        <?php 
        $featuredImage = wp_get_attachment_url(get_post_thumbnail_id( get_the_ID()));
        ?>
        
        <div class="aside-featured background-image" style="background-image:url(<?php echo  $featuredImage; ?>)">  </div><!--standard-featured-->
        
       <?php endif; ?>
            
              </div><!--col-xs-12 col-sm-4 col-md-3 -->
        
        
            <div class="col-xs-12 col-sm-9 col-md-10" >

                         <header class="entry-class">



                    <div class="entry-meta">
                    <?php echo shaheen_posted_meta(); ?>

                    </div><!--entryMeta-->

                </header>

                <div class="entry-content">


                    <div class="entry-excerpt">
                        <?php the_content(); ?>
                    </div><!--entry-excerpt-->


                </div><!--entry-content-->
            </div><!--col-xs-12-->
        
      
    
    </div><!--row-->
    

    
   
    
    <div class="entry-footer"> 
        <div class="row">
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2">
         <?php echo shaheen_posted_footer(); ?>
            </div><!--col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2-->
        </div><!--row-->
    </div><!--entry-footer-->
       </div><!--asideContainer-->
    
</article>