<?php

/*
@package shaheen
==================================
Image post fromat
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('shaheen-format-image'); ?>> 
     <?php   
        $featuredImage = '';
     if(has_post_thumbnail()): 
        $featuredImage = wp_get_attachment_url(get_post_thumbnail_id( get_the_ID()));
       
    else:
   
             $featuredImage = shaheen_get_attachment();
       
       
    endif;   
    ?>
    
    <header class="entry-class text-center background-image" style="background-image:url(<?php echo $featuredImage; ?>)">
    
         <?php the_title('<h1 class="entry-title">','</h1>'); ?>
        <div class="entry-meta">
        <?php echo shaheen_posted_meta(); ?>
        
        </div><!--entryMeta-->
        
         <div class="entry-excerpt">
            <?php the_excerpt(); ?>
        </div><!--entry-excerpt-->
        
    </header>
      
    
    <div class="entry-footer"> 
         <?php echo shaheen_posted_footer(); ?>
    </div><!--entry-footer-->
    
    
</article>