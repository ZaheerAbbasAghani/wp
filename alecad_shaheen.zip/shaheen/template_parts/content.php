<?php

/*
@package shaheen
==================================
Standard post fromat
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
    
    <header class="entry-class text-center">
    
         <?php the_title('<h1 class="entry-title">','</h1>'); ?>
        <div class="entry-meta">
        <?php echo shaheen_posted_meta(); ?>
        
        </div><!--entryMeta-->
        
    </header>
    
    <div class="entry-content">
    
      <?php   if(has_post_thumbnail()): ?>
        <?php 
        $featuredImage = wp_get_attachment_url(get_post_thumbnail_id( get_the_ID()));
        ?>
        
        <div class="standard-featured background-image" style="background-image:url(<?php echo  $featuredImage; ?>)">  </div><!--standard-featured-->
        
       <?php endif; ?>
        
        <div class="entry-excerpt">
            <?php the_excerpt(); ?>
        </div><!--entry-excerpt-->
        
        
    </div><!--entry-content-->
    
    <div class="button-container text-center">
        <a href="<?php the_permalink(); ?>" class="btn btn-default"  > 
        <?php _e('Read More'); ?>
        </a>
    </div>
    
    
    <div class="entry-footer"> 
         <?php echo shaheen_posted_footer(); ?>
    </div><!--entry-footer-->
    
    
</article>