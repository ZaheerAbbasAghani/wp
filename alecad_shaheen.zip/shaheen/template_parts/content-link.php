<?php

/*
@package shaheen
==================================
Link post fromat
=================================
*/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('shaheen-format-link'); ?>> 
    
    <header class="entry-class text-center">
     <?php $link = shaheen_grab_url(); ?>
         <?php the_title('<h1 class="entry-title"><a href="'.$link.'" target="_blank">','<div class="link-icon"><span class="glyphicon glyphicon-link"> </span></div></h1>'); ?>
      
        
    </header>
    
    
    
    
    
</article>