 <?php  wp_footer(); ?>

<footer class="shaheen-footer text-center">
<p> &copy <?php echo $date =  Date('Y'); ?>. All Rights Reserved </p>
</footer>

</body>
</html>