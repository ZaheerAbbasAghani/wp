<?php get_header(); ?>

    <div id="primary" class="content-area">
            
        <main id="main" class="site-main">
          
            <?php if(is_paged()): ?>
          
            <?php endif; ?>
            
            <div class="container sunset-posts-container">
                
                <?php
                
                if(have_posts()):
         
               
                    while(have_posts()): the_post();
                        
                        get_template_part('template_parts/content','page');

                    endwhile;
              
                endif;
                
                
                ?>
                
            </div><!--container-->
          
        </main>
        
    </div>

<?php get_footer(); ?>