<?php get_header(); ?>

    <div id="primary" class="content-area">
            
        <main id="main" class="site-main">
          
            <?php if(is_paged()): ?>
             <div class="container text-center container-load-previous">
            
                <a class="btn-shaheen-load shaheen-load-more" data-prev="1" data-page="<?php echo shaheen_check_paged(1); ?>" data-url= "<?php echo admin_url('admin-ajax.php'); ?>" >
                    <span class="glyphicon glyphicon-refresh"> </span> 
                    <span class="text"> Load Previous </span>
                </a>
            
            </div>
            <?php endif; ?>
            
            <div class="container sunset-posts-container">
                
                <?php
                
                if(have_posts()):
         
                echo '<div class="page-limit" data-page="'.get_site_url().'/'.shaheen_check_paged() .'"> ';
                    while(have_posts()): the_post();
                        
                        get_template_part('template_parts/content',get_post_format());

                    endwhile;
                echo "</div>";
                else:
                
                echo 0;
                
                endif;
                
                
                ?>
                
            </div><!--container-->
            
            <div class="container text-center">
            
                <a class="btn-shaheen-load shaheen-load-more" data-page="<?php echo shaheen_check_paged(1); ?>" data-url= "<?php echo admin_url('admin-ajax.php'); ?>" >
                    <span class="glyphicon glyphicon-refresh"> </span> 
                    <span class="text"> Load More </span>
                </a>
            
            </div>
        </main>
        
    </div>

<?php get_footer(); ?>