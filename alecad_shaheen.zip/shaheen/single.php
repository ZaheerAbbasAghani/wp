<?php get_header(); ?>

    <div id="primary" class="content-area">
            
        <main id="main" class="site-main">
          
          
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 ">
                <?php
                
                if(have_posts()):
         
               
                    while(have_posts()): the_post();
                        shaheen_save_posts_views(get_the_ID());
                        get_template_part('template_parts/single',get_post_format());
                    
                echo shaheen_post_navigation();
                
                //Checking comments and prin
                if(comments_open()):
                comments_template();
                endif;
                
                    endwhile;
            
             
                
                endif;
                
                
                ?>
                    </div><!--col-md-9-->
                </div><!--wrapper-->
            </div><!--container-->
         
        </main>
        
    </div>

<?php get_footer(); ?>