<?php 

/*
This is the template for Sidebar
@package shaheenthemes
*/

if(! is_active_sidebar('shaheen-widget')){
    return;
}
?>

<aside id='secondary' class="widget-area" role="complementary">
    <div class="shaheen-sidebar-container">
        <a  class="js-closeSidebar sidebar-close"><span aria-hidden="true">×</span></a>
        <div class="sidebar-scroll">
        <?php dynamic_sidebar('shaheen-widget'); ?>
        </div>
    </div>
</aside><!--end aside -->