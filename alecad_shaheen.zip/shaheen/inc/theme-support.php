<?php 

/*
@package shaheen
==================================
SHAHEEN THEME SUPPORT OPTIONS
=================================
*/

add_theme_support( 'post-formats', array('aside','gallery','link','image','quote','status','video','audio','chat'));


 $header =  get_option('custom_header');
 if(@$header==1){
	 
	 add_theme_support('custom-header');
	 
 }
 
$background =  get_option('custom_background');
 if(@$background==1){
	 
	 add_theme_support('custom-background');
	 
 }

add_theme_support('post-thumbnails');

// Shaheen Register Nav Menu    
function register_shaheen_nav_menu(){
    register_nav_menu('Primary','Header Navigation Menu');
    
}

add_action('after_setup_theme','register_shaheen_nav_menu');

/*
=====================================
ACTIVATE HTML5 THEME SUPPORT OPTIONS
=====================================
*/

add_theme_support('html5',array('comments_list','comments_form','search-form','gallery','caption'));

/*
=====================================
ACTIVATE SIDEBAR THEME SUPPORT OPTIONS
=====================================
*/

function shaheen_sidebar_init(){
    register_sidebar(
    array(
    'name'          => esc_html__('Shaheen Sidebar','shaheentheme'),
    'id'            => 'shaheen-widget',
    'description'   => 'Dynamic Right Sidebar',
    'before_widget' => '<section id="%1$s" class="shaheen-widget %2$s" >',
    'after_widget'  => '</section>',
    'before_title'  => '<h2 class="shaheen-widget-title">',
    'after_title'   => '</h2>',
    ));
} //end shaheen_sidebar_init
add_action('widgets_init','shaheen_sidebar_init');

/*
@package shaheen
==================================
BLOG LOOP CUSTOM FUNCTION
=================================
*/

function shaheen_posted_meta(){
	$posted_on = human_time_diff( get_the_time('U') , current_time('timestamp') );
	
	$categories = get_the_category();
	$separator = ', ';
	$output = '';
	$i = 1;
	
	if( !empty($categories) ):
		foreach( $categories as $category ):
			if( $i > 1 ): $output .= $separator; endif;
			$output .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" alt="' . esc_attr( 'View all posts in%s', $category->name ) .'">' . esc_html( $category->name ) .'</a>';
			$i++; 
		endforeach;
	endif;
	
	return '<span class="posted-on">Posted <a href="'. esc_url( get_permalink() ) .'">' . $posted_on . '</a> ago</span> / <span class="posted-in">' . $output . '</span>';
}


/* Diplay image attachments */
function shaheen_get_attachment( $num = 1 ){
	
	$output = '';
	if( has_post_thumbnail() && $num == 1 ): 
		$output = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
	else:
		$attachments = get_posts( array( 
			'post_type' => 'attachment',
			'posts_per_page' => $num,
			'post_parent' => get_the_ID()
		) );
		if( $attachments && $num == 1 ):
			foreach ( $attachments as $attachment ):
				$output = wp_get_attachment_url( $attachment->ID );
			endforeach;
		elseif( $attachments && $num > 1 ):
			$output = $attachments;
		endif;
		
		wp_reset_postdata();
		
	endif;
	
	return $output;
}


/* Function Footer */ 
function shaheen_posted_footer(){
    $comments_num = get_comments_number();
    if(comments_open()){
            
        if($comments_num == 0){
            $comments = __('No comments');
        }//innerif
        elseif ($comments_num > 1) {
            $comments = $comments_num . __('Comments');
        }
        else {
            $comments = __('1 comment');
        }
        $comments = '<a href="'.get_comments_link().'"> '.$comments.' </a>';
        
    }else {
        $comments =  __('Comments are Closed');
        
    }
    
	return '<div class="post-footer-container"> <div class="row"> <div class="col-xs-12 col-sm-6"> '. get_the_tag_list('<div class="tag-list"><span class="tags_icons"> </span>',' , ','</div>').' </div> <div class="col-xs-12 col-sm-6 text-right"> '. $comments.' </div></div></div>';
}


/* GRAB */

function shaheen_grab_url (){
    if(! preg_match('/<a\s[^>]*?href=[\'"](.+?)[\'"]/i',get_the_content(),$links)) {
        return false;
    }
    else {
        //$links[1];
        return esc_url_raw($links[1]);
    }
}




/* Single Posts Custom Function */ 


function shaheen_post_navigation(){
	
	$nav = '<div class="row NavPost">';
	
	$prev = get_previous_post_link( '<div class="post-link-nav"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> %link</div>', '%title' );
	$nav .= '<div class="col-xs-12 col-sm-6">' . $prev . '</div>';
	
	$next = get_next_post_link( '<div class="post-link-nav">%link <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></div>', '%title' );
	$nav .= '<div class="col-xs-12 col-sm-6 text-right">' . $next . '</div>';
	
	$nav .= '</div>';
	
	return $nav;
	
}

/* Share Custom Social Media Icons */ 
function shaheen_share_this( $content ){
	
	if( is_single() ){
	
		$content .= '<div class="shaheen-shareThis"><h4 class="text-center">Share This</h4>';
				
		$title = get_the_title();
		$permalink = get_permalink();
		
		$twitterHandler = ( get_option('twitter_handler') ? '&amp;via='.esc_attr( get_option('twitter_handler') ) : '' );
		
		$twitter = 'https://twitter.com/intent/tweet?text=Hey! Read this: ' . $title . '&amp;url=' . $permalink . $twitterHandler .'';
		$facebook = 'https://www.facebook.com/sharer/sharer.php?u=' . $permalink;
		$google = 'https://plus.google.com/share?url=' . $permalink;
			
		$content .= '<ul class="list-unstyled text-center list-inline">';
		$content .= '<li><a href="' . $twitter . '" target="_blank" rel="nofollow"><span class="shaheen-icon shaheen-twitter">Twitter</span></a></li>';
		$content .= '<li><a href="' . $facebook . '" target="_blank" rel="nofollow"><span class="shaheen-icon shaheen-facebook">Facebook</span></a></li>';
		$content .= '<li><a href="' . $google . '" target="_blank" rel="nofollow"><span class="shaheen-icon shaheen-googleplus">Google+</span></a></li>';
		$content .= '</ul></div><!-- .shaheen-share -->';
		
		return $content;
	
	} else {
		return $content;
	}
	
}
add_filter( 'the_content', 'shaheen_share_this' );

function mailtrap($phpmailer) {
  $phpmailer->isSMTP();
  $phpmailer->Host = 'smtp.mailtrap.io';
  $phpmailer->SMTPAuth = true;
  $phpmailer->Port = 2525;
  $phpmailer->Username = '0bec7844aeb11f';
  $phpmailer->Password = 'e3f71243200016';
}

add_action('phpmailer_init', 'mailtrap');