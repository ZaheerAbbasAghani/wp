<h1>  Shaheen Theme Support </h1>
<?php settings_errors(); ?>

<div id="shaheen-wrap-sidebar"> 



<div class="wrapSidebarForm">
<form method="post" action="options.php" class="shaheen-sidebar-form">
<?php settings_fields('shaheen-theme-support'); ?>
<?php do_settings_sections('shaheen_theme_options'); ?>
<?php submit_button(); ?>
</form>
</div><!--wrapSidebarForm-->


</div><!--shaheen-wrap-sidebar-->