<h1> Shaheen Custom Css </h1>
<?php settings_errors(); ?>

<form id="shaheen-save-custom-css" method="post" action="options.php">
<?php  settings_fields('shaheen-custom-css-options');?>
<?php  do_settings_sections('shaheen_css_settings_page');?>
<?php  submit_button('Save Changes'); ?>
</form>