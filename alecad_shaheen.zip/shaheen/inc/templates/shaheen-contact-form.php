<h1>  Shaheen Contact Form </h1>
<?php settings_errors(); ?>
<p> Use this <strong>shortcode</strong>  to activate contact form in page or post. </p>
<code> [contact_form] </code>
<div id="shaheen-wrap-sidebar"> 
    
<div class="wrapSidebarForm">
<form method="post" action="options.php" class="shaheen-sidebar-form">
<?php settings_fields('shaheen-contact-form'); ?>
<?php do_settings_sections('shaheen_theme_options_contact'); ?>
<?php submit_button(); ?>
</form>
</div><!--wrapSidebarForm-->


</div><!--shaheen-wrap-sidebar-->