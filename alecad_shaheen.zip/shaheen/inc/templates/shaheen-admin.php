<h1>  Shaheen Sidebar Options </h1>
<?php settings_errors(); ?>

<div id="shaheen-wrap-sidebar"> 
	<div class="shaheen-wrap-sidebar-inner">
	<?php $DPprofile = get_option('profile_picture'); ?>
		<div id="wrapUp" style="background-image:url(<?php echo $DPprofile; ?>) "></div><!--wrapUp-->
		
		<div id="shaheen-desc"> 
		<h3> <?php echo get_option('first_name'); ?> <?php echo get_option('last_name'); ?> </h3>
		<p> <?php echo get_option('user_description'); ?>  </p>
        
    
        
		</div>
		
	</div><!--shaheen-wrap-sidebar-inner-->


<div class="wrapSidebarForm" >
<form method="post" action="options.php" class="shaheen-sidebar-form">
<?php  settings_fields('shaheen-settings-group'); ?>
<?php do_settings_sections('shaheen_theme'); ?>
<?php submit_button('Save Changes','primary','btnSubmit'); ?>
</form>
</div><!--wrapSidebarForm-->


</div><!--shaheen-wrap-sidebar-->