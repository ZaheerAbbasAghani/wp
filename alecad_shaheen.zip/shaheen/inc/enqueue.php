<?php 


/*
@package shaheen
==================================
ADMIN ENQUEUE PAGE
==================================
*/

function shaheen_load_admin_scripts($hook) {
   
	if('toplevel_page_shaheen_theme'==$hook){
	
	wp_enqueue_media();
	wp_enqueue_style('shaheen_admin',get_template_directory_uri().'/css/shaheen_admin.css',array(),'1.0.0','all');
	wp_enqueue_script('shaheen_adminJS',get_template_directory_uri().'/js/shaheen-admin.js',array(),'1.0.0','all');
	}
    
    else if('shaheen_page_shaheen_css_settings'==$hook) {
        
  wp_enqueue_style('shaheen_admin_ace',get_template_directory_uri().'/css/shaheen_ace.css',array(),'1.0.0','all');
	 
   wp_enqueue_script('shaheen-ace-script', get_template_directory_uri().'/js/ace/ace.js',array(),'1.2.1',true);
	
        
    wp_enqueue_script('shaheen-custom-css-script', get_template_directory_uri().'/js/ace/shaheen_custom_style.js',array(),'1.0.0',true);

    }//end elseif
   
    
    else { return; }
} //endfunction




add_action('admin_enqueue_scripts','shaheen_load_admin_scripts');

/*

Functions For Enqueue Scripts in Frontend...

*/


function shaheen_load_frontend_scripts() {

wp_enqueue_style('bootstrap',get_template_directory_uri().'/css/bootstrap.min.css',array(),'3.2.0','all');
 wp_enqueue_style('shaheen',get_template_directory_uri().'/style.css',array(),'1.0.0','all');
wp_enqueue_style('shaheenCustom',get_template_directory_uri().'/css/shaheen.css',array(),'1.0.0','all');
wp_enqueue_style('Raleway','https://fonts.googleapis.com/css?family=Raleway');
    
//wp_deregister_script('jquery'); //cancel or remove any script
//wp_register_script(); //to add your own script in wordpress
wp_enqueue_script('bootstrap',get_template_directory_uri().'/js/bootstrap.min.js',array('jquery'),'3.2.0',true);
    


}

add_action('wp_enqueue_scripts','shaheen_load_frontend_scripts');


function shaheen_ajax_enqueue() {

    wp_enqueue_script( 'ajax-script', get_template_directory_uri() . '/js/shaheen.js', array('jquery'),'1.0.0',true);

    wp_localize_script( 'ajax-script', 'my_ajax_object',
            array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    
   
    
}
add_action( 'wp_enqueue_scripts', 'shaheen_ajax_enqueue' );















