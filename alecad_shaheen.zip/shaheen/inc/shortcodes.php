<?php

/*
@package shaheen
==================================
SHAHEEN SHORTCODES
=================================
*/
 // Shaheen Tooltip
function shaheen_tooltip($atts , $content = null){
 
    // get the attributes
    $atts = shortcode_atts(
    array(
        
        'placement'=>'top',
        'title' => '',
    ),
     $atts,
    'tooltip'
    );
    
    $title = ($atts['title'] == '' ? $content : $atts['title'] );
    
    // return HTML
    return '<span class="shaheen-tooltip" data-toggle="tooltip" data-placement="'.$atts['placement'].'" title="'.$title.'">'.$content.'</span>';
    
}//endfunction 

add_shortcode('tooltip','shaheen_tooltip');

 // Shaheen Popover

function shaheen_popover($atts , $content = null){
 
    // get the attributes
    $atts = shortcode_atts(
    array(
        
        'placement'=>'top',
        'title' => '',
    ),
     $atts,
    'tooltip'
    );
    
    $title = ($atts['title'] == '' ? $content : $atts['title'] );
    
    // return HTML
    return '<button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="'.$atts['placement'].'" data-content="'.$content.'">'.$title.'</button>';
    
    //return '<span class="shaheen-tooltip" data-toggle="tooltip" data-placement="'.$atts['placement'].'" title="'.$title.'">'.$content.'</span>';
    
}//endfunction

add_shortcode('popover','shaheen_popover');


/*
<button type="button" class="btn btn-default" data-toggle="tooltip" data-placement="left" title="Tooltip on left">Tooltip on left</button>


<button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
  Popover on left
</button>
*/

// Add contact form shortcode [contact_form]
function shaheen_contact_form($atts , $content = null){
 
    // get the attributes
    $atts = shortcode_atts(
    array(),
     $atts,
    'contact_form'
    );
 
    // return HTML
    ob_start();
    include 'templates/shaheen_contact_form.php';
    return ob_get_clean();
    
}//endfunction

add_shortcode('contact_form','shaheen_contact_form');


































