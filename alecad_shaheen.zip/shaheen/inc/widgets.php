<?php 

/*
WIDGET CLASS
@package shaheenthemes
*/

class Shaheen_Profile_Widget extends WP_Widget{
    
    // SETUP THE WIDGET NAME , DESCRIPTION ETC
    
    public function __construct() {
        
        $widget_ops = array(
            'classname'   => 'shaheen-profile-widget',
            'description' => 'Cusotm Shaheen Profile Widget',
        );
        
        parent::__construct ('shaheen_profile','Shaheen Profile', $widget_ops);
        
    } //endConstruct
    
    // BACKEND DISPLAY OF WIDGET
public function form ($instance){
    echo "<p> No options for this widget </p><p>You can control the fields of this widget from <a href='./admin.php?page=shaheen_theme'> This Page </a> </p>";
}


// FRONTEND DISPLAY OF WIDGET
public function widget($args , $instance){
    
     ?>
    <div class="sidebarContainer">
    <div class="shaheen-wrap-sidebar-inner">
	<?php $DPprofile = get_option('profile_picture'); ?>
        <div id="wrapUp" style="background-image:url(<?php echo $DPprofile; ?>) ">
        </div><!--wrapUp-->
		
		<div id="shaheen-desc"> 
		<h3> <?php echo get_option('first_name'); ?> <?php echo get_option('last_name'); ?> </h3>
		<p> <?php echo get_option('user_description'); ?>  </p>
        
        <div class="shaheen-icon-wrappers">
        <?php
        $twitter_handler = get_option('twitter_handler'); 
        $facebook_handler = get_option('facebook_handler'); 
        $gplus_handler = get_option('gplus_handler');
        
        if(!empty($twitter_handler)){ ?>
            <a href="http://twitter.com/<?php echo $twitter_handler; ?>"><span> Twitter </span></a>
        <?php } ?>

        <?php if(!empty($facebook_handler)){ ?>
            <a href="https://facebook.com/<?php echo $facebook_handler; ?>"> <span> Facebook </span> </a>
        <?php } ?>

        <?php if(!empty($gplus_handler)){ ?>
           <a href="https://plus.google.com/u/0/+<?php echo $gplus_handler; ?>">  <span> Google+ </span> </a>
        <?php } ?>
        
            
        </div><!--shaheen-icon-wrappers-->
        
		</div>
		
	</div><!--shaheen-wrap-sidebar-inner-->
    </div>
<?php 
    echo $args['before_widget'];
    echo $args['after_widget'];
}
    
}



add_action('widgets_init',function() {
    register_widget('Shaheen_Profile_Widget');
});


/* Change Cloud Tags Font Size */

function shaheen_tag_cloud_font_style($args){
    
    $args['smallest'] = 8;
    $args['largest'] = 8;
    
    return $args;
}
add_filter('widget_tag_cloud_args','shaheen_tag_cloud_font_style');
    

/* 
SAVE POSTS VIEWS 
*/

function shaheen_save_posts_views($postID) {
    $metakey = 'shaheen_posts_views' ;
    $views = get_post_meta($postID, $metakey, true);
    $count = (empty($views) ? 0 : $views);
    $count++;
    update_post_meta($postID,$metakey,$count);  
    echo '<h1>'.$views.'</h1>';
}
remove_action('wp_head','adjacent_posts_rel_link_wp_head',10,0);

/*
	Popular Posts Widget
*/
class Shaheen_Popular_Posts_Widget extends WP_Widget {
	
	//setup the widget name, description, etc...
	public function __construct() {
		
		$widget_ops = array(
			'classname' => 'shaheen-popular-posts-widget',
			'description' => 'Popular Posts Widget',
		);
		parent::__construct( 'shaheen_popular_posts', 'shaheen Popular Posts', $widget_ops );
		
	}
	
	// back-end display of widget
	public function form( $instance ) {
		
		$title = ( !empty( $instance[ 'title' ] ) ? $instance[ 'title' ] : 'Popular Posts' );
		$tot = ( !empty( $instance[ 'tot' ] ) ? absint( $instance[ 'tot' ] ) : 4 );
		
		$output = '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">Title:</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" value="' . esc_attr( $title ) . '"';
		$output .= '</p>';
		
		$output .= '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'tot' ) ) . '">Number of Posts:</label>';
		$output .= '<input type="number" class="widefat" id="' . esc_attr( $this->get_field_id( 'tot' ) ) . '" name="' . esc_attr( $this->get_field_name( 'tot' ) ) . '" value="' . esc_attr( $tot ) . '"';
		$output .= '</p>';
		
		echo $output;
		
	}
	
	//update widget
	public function update( $new_instance, $old_instance ) {
		
		$instance = array();
		$instance[ 'title' ] = ( !empty( $new_instance[ 'title' ] ) ? strip_tags( $new_instance[ 'title' ] ) : '' );
		$instance[ 'tot' ] = ( !empty( $new_instance[ 'tot' ] ) ? absint( strip_tags( $new_instance[ 'tot' ] ) ) : 0 );
		
		return $instance;
		
	}
	
	//front-end display of widget
	public function widget( $args, $instance ) {
		
		$tot = absint( $instance[ 'tot' ] );
		
		$posts_args = array(
			'post_type'			=> 'post',
			'posts_per_page'	=> $tot,
			'meta_key'			=> 'shaheen_posts_views',
			'orderby'			=> 'meta_value_num',
			'order'				=> 'DESC'
		);
		
		$posts_query = new WP_Query( $posts_args );
		
		echo $args[ 'before_widget' ];
		
		if( !empty( $instance[ 'title' ] ) ):
			
			echo $args[ 'before_title' ] . apply_filters( 'widget_title', $instance[ 'title' ] ) . $args[ 'after_title' ];
			
		endif;
		
		if( $posts_query->have_posts() ):
		
			echo '<ul>';
				
				while( $posts_query->have_posts() ): $posts_query->the_post();
					
					echo '<li>' . get_the_title() . '</li>';
					
				endwhile;
				
			echo '</ul>';
		
		endif;
		
		echo $args[ 'after_widget' ];
		
	}
	
}
add_action( 'widgets_init', function() {
	register_widget( 'shaheen_Popular_Posts_Widget' );
} );
