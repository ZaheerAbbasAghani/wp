<?php 

/*
This is the template for header
@package shaheenthemes
*/
?>

<!DOCTYPE HTML>
<html <?php language_attributes(); ?> >
<head>
    <title><?php bloginfo('name'); echo ' >> ';  the_title(); ?> </title>
    <meta name="description" content="<?php bloginfo('description'); ?>"/>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmp.org/xfn/11"/>
    <?php  if(is_singular() && pings_open(get_queried_object())) :  ?>
    <link rel="pingback" href="<?php bloginfo('pingback_url');  ?>"/>
    <?php endif; ?>
    <?php  wp_head(); ?>
</head>

<body class="<?php body_class(); ?> ">
  
    <div class="shaheen-sidebar">
        
        <div class="sidebar-scroll">
            <?php get_sidebar(); ?>
        </div><!-- sidebar-scroll -->
    
    </div><!--shaheen-sidebar-->
    
    
    <div class="sidebar-overlay"></div>
    
    <div class="container-fluid1">
        <div class=""> 

            
          <header class="header-container text-center" style="background-image:url('<?php header_image(); ?>')">
            
<div class=""><a  class="js-openSidebar sidebar-open"> <span class="glyphicon glyphicon-hand-left" aria-hidden="true"></span>    </a></div>
              
             <div class="header-content table">
                
                 <div class="table-cell">
                    <h1 class="site-title"><?php bloginfo('name'); ?></h1><!--site-title-->
                    <h2 class="site-decription"> <?php bloginfo('description'); ?> </h2><!--site-decription-->
                 </div><!--table-cell-->
                
                </div><!--header-content-->
            <div class="navbar-container">
              
            <nav class="navbar navbar-default shaheen-navbar">
                 
                
                <?php
                
                wp_nav_menu( array('theme_location'=>'Primary',
                                  'container'=> false,
                                  'menu_class'=>'nav navbar-nav',
                                   'walker'=> new Shaheen_Walker_Nav_Primary,
                                  ) 
                            ); 
                ?>
            </nav>
            </div><!--navbar-container-->
                    
            
            </header><!--header-container -->    
        
        </div><!--.row-->
    </div><!--.container-->


