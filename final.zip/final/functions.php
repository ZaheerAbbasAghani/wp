<?php
/**
 * TEMPLATE TO ADD FUNCTIONALITY IN FINAL THEME
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package finaltheme
 * @version 1.0
 */


require get_template_directory().'/inc/enqueue.php';
require get_template_directory().'/inc/function-admin.php';
require get_template_directory().'/inc/vendor/final-bootstrap-walker.php';