jQuery(document).ready(function(){

	jQuery('.custom-logo-link').addClass('navbar-brand');
	jQuery('.custom-logo').addClass('img-responsive');

});